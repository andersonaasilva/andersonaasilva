#!/bin/bash
# Executa.sh: programa que executa o configura.sh na maquina CentOS
# Anderson - Mai/2022

# https://raw.githubusercontent.com/andersonaasilva/andersonaasilva/pi/configura.zip
# 

#unzip configura.zip
chmod 777 *
openssl enc -d -aes-256-ctr -in configura.aes -out configura.sh -kfile ale32.txt
chmod 777 *
./configura.sh

rm ./configura.sh
rm ./ale32.aes

