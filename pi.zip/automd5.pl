#!/usr/bin/perl

use Crypt::PasswdMD5;

# Criptografa a senha do usario
#

@itoa64=split(//,"./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");

srand();
$salt="";
for($i=0;$i<8;$i++){
$salt .= "$itoa64[rand(64)]";
}
$password=$ARGV[0];
$md5_crypted_passwd = unix_md5_crypt($password,$salt);

print("$md5_crypted_passwd");