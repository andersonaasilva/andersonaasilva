#!/bin/bash
# Configura.sh: programa que configura a maquina CentOS
# Anderson - Mai/2022

# cria a pasta /pi e acerta a permissao
mkdir /pi
chmod 777 /pi
cd /pi

# bloqueia conexoes root no ssh
echo PermitRootLogin no >> /etc/ssh/sshd_config
systemctl restart sshd.service


# adiciona usuarios (sem senha)
useradd fulano
useradd beltrano
useradd cicrano
useradd admin
useradd americano
useradd alemao
useradd frances
useradd espanhol
useradd italiano
useradd brasileiro
useradd russo

# muda o modo do arquivo /etc/shadow para alteração
cp /etc/shadow /etc/shadow.default
chmod 600 /etc/shadow

# desabilita as linhas especificas do arquivo /etc/shadow
sed -i 's/root:/#root:/' /etc/shadow
sed -i 's/azureuser:/#azureuser:/' /etc/shadow
sed -i 's/fulano:/#fulano:/' /etc/shadow
sed -i 's/beltrano:/#beltrano:/' /etc/shadow
sed -i 's/cicrano:/#cicrano:/' /etc/shadow
sed -i 's/admin:/#admin:/' /etc/shadow
sed -i 's/americano:/#americano:/' /etc/shadow
sed -i 's/alemao:/#alemao:/' /etc/shadow
sed -i 's/frances:/#frances:/' /etc/shadow
sed -i 's/espanhol:/#espanhol:/' /etc/shadow
sed -i 's/italiano:/#italiano:/' /etc/shadow
sed -i 's/brasileiro:/#brasileiro:/' /etc/shadow
sed -i 's/russo:/#russo:/' /etc/shadow

# repassa hash de senhas para o arquivo /etc/shadow
echo root:$6$1.b0mEeJ$FqqUy89xo9TkKUAEm7zXrJM/wlReSJRwxbmZPTJJCNP7Zvd3Ww7plfZb6e74SSuXKCL3KuzvMwnU6VkQwoYat.:19123:::::: >> /etc/shadow
echo azureuser:$6$TM0dWH5SufUDCVSS$WW1.nMf7Gd3QbO1zSfrjHAjfJiHIpBnCoCYsAudbUH9E7uBvXuw92NY2UEyTTBcurQA49ka5oMdIIq5FRckSl1:19123:0:99999:7::: >> /etc/shadow
echo fulano:$6$Ia1yYU0R$Lf7Z3aYy1WfSQL5Ir9wLHKDzqVdzDiGvh22ATcKVywGbW.pCdu3AXWq8RkygG6959a4Sr8KLoBYeCGPaYgxxu0:19123:0:99999:7::: >> /etc/shadow
echo beltrano:$6$A.KQfnHB$8fABskX/kX2Q9r8KaDxQ74N5sq9sBWQH6vpr1yV6GaRUzY6A4h4IFlXlJgtxf2MrTbdazdYQlOk22SZZSov7B0:19123:0:99999:7::: >> /etc/shadow
echo cicrano:$6$tfOUvCa2$26MuBjZbAzp4DeSHsuY1F2bfiVXxrpooU0PrSOlOpoqIXIOG/aYzLAWx6SozSFvogUWmBuaL5m/LRhbZPpPSY0:19123:0:99999:7::: >> /etc/shadow
echo admin:$6$z/s0Nnw1$KIvTIrmiDMjbWPDUNSD2tpG2UGaA4jBcTw4E/gsHgQ2bdyPvkubbtKOG3SRZsp1urAB5vO62mWgGSVFzG6kzV1:19123:0:99999:7::: >> /etc/shadow
echo americano:$6$AgUKJh2P$Sb1VmrkCxSB9LWoSaqSA9X04YIZvAexa1uztAcD0PH4zY/mIrZLTaaRyhbKEhbpyTgFmKCXLIDpSibt80ruPL/:19123:0:99999:7::: >> /etc/shadow
echo alemao:$6$W.7ep6oQ$JvrJZjrGwD0l/7r3RKZo9A.XG7Bc/lJOfZlD399.roEffCIXB8fZdcdVBLkAeIMuCsYRwjyhamPvBO1aGVC4o1:19123:0:99999:7::: >> /etc/shadow
echo frances:$6$eLLPzO5z$KXdp9PAxa4aCIbyUz/AcYbrBZjRTrCcXuYL8FrSQ4/kADQqgUAf9buIsL.6RMiXB9onqD8t21XqYXrnp8J6Zv0:19123:0:99999:7::: >> /etc/shadow
echo espanhol:$6$RbBlolu9$K8FJBMaJEKTCb0p3B2w4st6B/7xig0Tzk5DZDJPv2/r6TYzojJFYB7inDuDfKKf1pbk2wIpKeZnSf0/LLKzEv/:19123:0:99999:7::: >> /etc/shadow
echo italiano:$6$4QbFYqaq$ca0LNfApqUxpyJJkUZa20LdLe/oa4VMA0RSGDuFOTRzR9fVxTfUAaAituhFVT37daXIbVqGg5COhxAQWBDPPL.:19123:0:99999:7::: >> /etc/shadow
echo brasileiro:$6$glunzobR$fBP.VuvVglk.KwnADwrf.XJCI9E8lSBQGspKVSM7I71OyZquodSJf/oSeMvhRhg4IxI0cXTHT.JcSpOKgXWbd.:19123:0:99999:7::: >> /etc/shadow
echo russo:$6$ud8JpmIe$/lsgOm1hC9wH2zUh4pEX3nlMuMuX92VQN7a8WTGD6UYuStGwt74wIYtnubDeRwajTg1ymodmCo6J0gqeT5QhS1:19123:0:99999:7::: >> /etc/shadow

# retorna o modo do arquivo /etc/shadow para so leitura
chmod 400 /etc/shadow


# instala servidor web como servico
yum install httpd
yum update httpd
systemctl start httpd
systemctl enable httpd.service

# instala servidor ftp como servico
yum install vsftpd
yum update vsftpd
systemctl start vsftpd
systemctl enable vsftpd.service



