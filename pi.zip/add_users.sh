#!/bin/bash

IFS='
'

for LISTA in `cat autousers.txt | cut -d , -f 1`
do
senhausuario=`cat autousers.txt | grep $LISTA | cut -d , -f 2`
senhacript=`/usr/bin/perl automd5.pl $senhausuario`
varinvalido=`echo $senhacript | egrep '[ ]'`
# Adiciona usuario no sistema sem shell, cria a pasta e dรก permissao
/usr/sbin/useradd $LISTA -s /bin/false -d /home/$LISTA -p $senhacript
/bin/mkdir -p /home/$LISTA
/bin/chown $LISTA /home/$LISTA -R
done

exit 0